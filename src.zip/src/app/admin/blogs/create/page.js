import BlogForm from "@/app/components/BlogForm";

export default function CreateBlog() {
  return <BlogForm />;
}
