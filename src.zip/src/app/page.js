
import Admin from "./admin/page";

export default function Home() {
  return (
    <div>
      <Admin/>
    </div>
  );
}
